<?php 
// Enter your Host, username, password, database below.
// I left password empty because i do not set password on localhost.
//$connect = mysqli_connect("localhost","root","","amma");
// Check connection
//if (mysqli_connect_errno())
  //{
  //echo "Failed to connect to MySQL: " . mysqli_connect_error();
 // }
  //date_default_timezone_set('Asia/Kolkata');
$hostname="localhost";
$username="root";
$password="";
$database="amma";
$connect=mysqli_connect($hostname,$username,$password)or die('could not connect');
mysqli_select_db($connect,$database) or die ('could not database');
date_default_timezone_set('Asia/Kolkata');
?>
